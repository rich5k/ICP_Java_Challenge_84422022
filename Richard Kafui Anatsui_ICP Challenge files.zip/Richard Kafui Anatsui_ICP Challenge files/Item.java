/**
 *
 * @author Richard Anatsui
 * @Modifier Kojo A E Armah
 *
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 *
 */
public class Item {
    private String name;
    private double price;
    private int quantity;

    /**
     * A method to store a new item as an object given that the attributes are provided as shown below
     * @param name Stores the name of an item as a string
     * @param price Stores the price of an item as a double
     * @param quantity Stores the quantity of stock as an int
     */
    public Item(String name, double price, int quantity){
        this.name = name;
        this.price= price;
        this.quantity= quantity;
    }

    /**
     *
     * @return A method that returns an item's name as string
     */
    public String getName(){
        return name;
    }

    /**
     *
     * @return A method that returns the price of an item as a double value
     */
    public double getPrice(){
        return price;
    }

    /**
     * @return A method that returns the quantity available of the item as an int value
     */
    public int getQuantity(){
        return quantity;
    }

    /**
     * A method that sets the name of a particular item
     * @param n The name of an item is set to a String n
     */
    public void setName(String n){
        name = n;
    }

    /**
     * A method to set the price of a particular item
     * @param p The price of an item is set to a double value p
     */
    public void setPrice(double p){
        price = p;
    }

    /**
     * A method to set the quantity of a particular item
     * @param q The quantity of an item is set to an int value q
     */
    public void setQuantity(int q){
        quantity=q;
    }

    /**
     * A method to add a new item that doesn't already exist to the stock
     * @param itemName Stores the item's name as a String
     * @param quantity Stores the item's quantity as an int value
     * @param price Stores the item's price as a double value
     */
    public void addItem(String itemName, int quantity, double price){
        setName(itemName);
        setPrice(price);
        setQuantity(quantity);
        writingTextToFile();
    }

    /**
     * A method to write the list of items, with their price and quantities to a file.
     * This method return voids
     */
    public void writingTextToFile() {
  		    
    		PrintWriter printWriter = null;
    		
    		try {
    			File newFile = new File("essentials_stock.txt");
                        //Note that we are able to append to the file because of the "true" parameter
    			printWriter = new PrintWriter(new FileOutputStream(newFile, true));
                        
                        if(newFile.length()==0){
                            printWriter.println("Item   Quantity    Price");
                            printWriter.print(getName()+"\t");
                            printWriter.print(getQuantity()+"\t");
                            printWriter.print("GHC "+getPrice()+"\t");
                            printWriter.println();
                    
                            //Close Writer
                            printWriter.close();
                    
                            backup();
                        }
                        else{
                            printWriter.print(getName()+"\t");
                            printWriter.print(getQuantity()+"\t");
                            printWriter.print("GHC "+getPrice()+"\t");
                            printWriter.println();
                    
                            //Close Writer
                            printWriter.close();
                    
                            backup();
                        }
                        
    		}catch(FileNotFoundException fnfe) {
    			fnfe.getMessage();
    		}
                
                
  		   
  		    
  		    
                    printWriter.print(getName()+"\t");
                    printWriter.print(getQuantity()+"\t");
                    printWriter.print("GHC "+getPrice()+"\t");
                    printWriter.println();
                    
  		    //Close Writer
  		    printWriter.close();
                    
                    backup();
  	}

    /**
     * A method that duplicates the existing storage file
     */
    public void backup(){
         //
         String fileName1= "essentials_stock.txt";
         try{
            BufferedReader br1=null;
            File fileThatChanges= new File(fileName1);
        
            FileWriter fr1 = null; 
            
            //creates a temporary file to store the new content of the essentils stock file
            File tempFile = new File("backup_essentials_stock.txt");
            
            //reads the stock file sheet
            br1 = new BufferedReader(new FileReader(fileThatChanges));

            //flags the tempfile to overwrite file
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile,false));

           
            
            writer.close(); 
            br1.close();
            
            
            //overwrite the destination(attendeeSheet) file if it exists, and copy
            // the file attributes, including the rwx permissions
            Path fromFile = Paths.get(fileName1);
            Path toFile = Paths.get("backup_essentials_stock.txt");
            CopyOption[] c_Options = new CopyOption[]{
            StandardCopyOption.REPLACE_EXISTING,
            StandardCopyOption.COPY_ATTRIBUTES
            }; 
            Files.copy(fromFile, toFile, c_Options);
            }
         // An exception to cathc any incorrerct inputs
         catch(IOException e){
             e.printStackTrace();
         }
    }

    /**
     * A method to display the contents of the saved file that stores the list of all the items
     * with their appropriate price and quantity
     */
    public void display(){
        BufferedReader br;
        
        //reads the essentials_stock file, creates item objects and adds them to an array of students
        try{
            String fileName= "essentials_stock.txt";
            
            
            br= new BufferedReader(new FileReader(fileName));
            //assigns each line of the file to "line"
            String line= br.readLine();
            
            
            //while it is not at the end of the text file
            while(line != null){
                //print out each line
                System.out.println(line);
                
                
                //reads next line
                line= br.readLine();
            }
            //closes file
            br.close();
            }catch(IOException e){
            e.printStackTrace();
        }
    }
    
}
